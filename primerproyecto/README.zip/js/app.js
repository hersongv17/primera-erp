/**
 * Lógica principal de interacción para el Portal de Noticias NOVA PRESS
 */

document.addEventListener('DOMContentLoaded', () => {
  // Helpers seguros de almacenamiento para compatibilidad total con navegadores y Neocities
  const storage = {
    getBookmarks: () => {
      try { return JSON.parse(localStorage.getItem('novapress_bookmarks') || '[]'); }
      catch (e) { return []; }
    },
    setBookmarks: (data) => {
      try { localStorage.setItem('novapress_bookmarks', JSON.stringify(data)); }
      catch (e) {}
    },
    getTheme: () => {
      try { return localStorage.getItem('novapress_theme') || 'dark'; }
      catch (e) { return 'dark'; }
    },
    setTheme: (theme) => {
      try { localStorage.setItem('novapress_theme', theme); }
      catch (e) {}
    }
  };

  // Estado global de la aplicación
  const state = {
    currentCategory: 'all',
    searchQuery: '',
    bookmarks: storage.getBookmarks(),
    theme: storage.getTheme(),
    currentArticle: null,
    speechSynthesisUtterance: null,
    isSpeaking: false,
    fontSizeMultiplier: 1,
    threeInstance: null
  };

  // Referencias DOM
  const elements = {
    newsGrid: document.getElementById('news-grid'),
    featuredContainer: document.getElementById('featured-news'),
    breakingTicker: document.getElementById('breaking-ticker'),
    categoryButtons: document.querySelectorAll('.category-btn'),
    searchInput: document.getElementById('search-input'),
    themeToggleBtn: document.getElementById('theme-toggle-btn'),
    themeIcon: document.getElementById('theme-icon'),
    bookmarkCount: document.getElementById('bookmark-count'),
    bookmarkBtn: document.getElementById('bookmark-btn'),
    bookmarksModal: document.getElementById('bookmarks-modal'),
    closeBookmarksBtn: document.getElementById('close-bookmarks-btn'),
    bookmarksList: document.getElementById('bookmarks-list'),
    
    // Modal de Noticia Completa
    articleModal: document.getElementById('article-modal'),
    closeArticleBtn: document.getElementById('close-article-btn'),
    modalCategory: document.getElementById('modal-category'),
    modalTitle: document.getElementById('modal-title'),
    modalAuthor: document.getElementById('modal-author'),
    modalAuthorRole: document.getElementById('modal-author-role'),
    modalDate: document.getElementById('modal-date'),
    modalReadTime: document.getElementById('modal-read-time'),
    modalImage: document.getElementById('modal-image'),
    modalContent: document.getElementById('modal-content'),
    modalLikeBtn: document.getElementById('modal-like-btn'),
    modalLikeCount: document.getElementById('modal-like-count'),
    modalClapBtn: document.getElementById('modal-clap-btn'),
    modalClapCount: document.getElementById('modal-clap-count'),
    modalBookmarkBtn: document.getElementById('modal-bookmark-btn'),
    modalTtsBtn: document.getElementById('modal-tts-btn'),
    modalShareBtn: document.getElementById('modal-share-btn'),
    fontIncreaseBtn: document.getElementById('font-increase-btn'),
    fontDecreaseBtn: document.getElementById('font-decrease-btn'),
    
    // Comentarios
    commentsList: document.getElementById('comments-list'),
    commentForm: document.getElementById('comment-form'),
    commentInput: document.getElementById('comment-input'),
    commentUserInput: document.getElementById('comment-user-input'),

    // Newsletter
    newsletterForm: document.getElementById('newsletter-form'),
    newsletterEmail: document.getElementById('newsletter-email'),
    toastNotification: document.getElementById('toast-notification'),
    toastMessage: document.getElementById('toast-message'),

    // Controles 3D
    modelGlobeBtn: document.getElementById('model-globe-btn'),
    modelCubeBtn: document.getElementById('model-cube-btn'),
    modelPrismBtn: document.getElementById('model-prism-btn'),
    themeCyanBtn: document.getElementById('theme-cyan-btn'),
    themeAmberBtn: document.getElementById('theme-amber-btn'),
    themePurpleBtn: document.getElementById('theme-purple-btn'),
    speedSlider: document.getElementById('speed-slider'),
    speedLabel: document.getElementById('speed-label'),
    floating3dTrigger: document.getElementById('floating-3d-trigger'),
    hero3dCard: document.getElementById('hero-3d-card')
  };

  // Inicializar 3D Scene
  if (typeof window.init3DNewsIcon === 'function') {
    state.threeInstance = window.init3DNewsIcon('three-canvas-container');
  }

  // Configurar Tema Inicial (Claro / Oscuro)
  applyTheme(state.theme);

  // Fecha en tiempo real en español
  const dateEl = document.getElementById('current-live-date');
  if (dateEl) {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const today = new Intl.DateTimeFormat('es-ES', options).format(new Date());
    dateEl.textContent = today.charAt(0).toUpperCase() + today.slice(1);
  }

  // Inicializar Marquesina de Última Hora
  initBreakingTicker();

  // Renderizar Noticias Iniciales
  renderFeaturedNews();
  renderNewsList();
  updateBookmarkBadge();

  // Configurar Oyentes de Eventos
  setupEventListeners();

  /* ==========================================================================
     FUNCIONES DE RENDERIZADO
     ========================================================================== */

  // Marquesina de noticias urgentes
  function initBreakingTicker() {
    if (!elements.breakingTicker) return;
    const itemsHtml = BREAKING_NEWS.map(item => `
      <span class="inline-block px-4 py-1 font-medium cursor-pointer hover:underline text-xs md:text-sm">
        ${item}
      </span>
    `).join('<span class="opacity-40 mx-2">•</span>');
    elements.breakingTicker.innerHTML = itemsHtml + '<span class="opacity-40 mx-2">•</span>' + itemsHtml;
  }

  // Renderizar Noticia Destacada en el Hero
  function renderFeaturedNews() {
    if (!elements.featuredContainer) return;
    const featured = NEWS_DATA.find(n => n.featured) || NEWS_DATA[0];
    const isBookmarked = state.bookmarks.includes(featured.id);

    elements.featuredContainer.innerHTML = `
      <article class="relative group bg-slate-800/80 rounded-2xl overflow-hidden border border-slate-700/60 shadow-2xl backdrop-blur-md transition-all duration-300 hover:border-cyan-500/50 hover:shadow-cyan-500/10">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-0">
          <div class="lg:col-span-7 relative h-72 sm:h-96 lg:h-auto overflow-hidden">
            <img src="${featured.image}" alt="${featured.title}" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy">
            <div class="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent lg:hidden"></div>
            <span class="absolute top-4 left-4 px-3.5 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/30 flex items-center gap-1.5">
              <span class="w-2 h-2 rounded-full bg-slate-950 animate-ping"></span>
              PORTADA EXCLUSIVA
            </span>
          </div>

          <div class="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div class="flex items-center gap-3 text-xs text-slate-400 mb-3">
                <span class="text-cyan-400 font-medium uppercase tracking-wider">${featured.categoryName}</span>
                <span>•</span>
                <span>${featured.date}</span>
                <span>•</span>
                <span>⏱️ ${featured.readTime}</span>
              </div>

              <h2 class="text-2xl sm:text-3xl font-extrabold text-white leading-tight mb-4 group-hover:text-cyan-400 transition-colors">
                ${featured.title}
              </h2>

              <p class="text-slate-300 text-sm leading-relaxed mb-6 line-clamp-3">
                ${featured.summary}
              </p>
            </div>

            <div class="pt-4 border-t border-slate-700/60 flex items-center justify-between">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white shadow-md">
                  ${featured.author.charAt(0)}
                </div>
                <div>
                  <p class="text-sm font-bold text-white">${featured.author}</p>
                  <p class="text-xs text-slate-400">${featured.authorRole}</p>
                </div>
              </div>

              <div class="flex items-center gap-2">
                <button onclick="window.toggleBookmark(${featured.id})" class="p-2.5 rounded-xl border border-slate-700 bg-slate-800 text-slate-300 hover:text-cyan-400 hover:border-cyan-500 transition-colors" title="Guardar para después">
                  <i class="${isBookmarked ? 'fa-solid text-cyan-400' : 'fa-regular'} fa-bookmark"></i>
                </button>
                <button onclick="window.openArticleModal(${featured.id})" class="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/20 transition-all transform hover:-translate-y-0.5 flex items-center gap-2">
                  <span>Leer Reportaje</span>
                  <i class="fa-solid fa-arrow-right text-xs"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </article>
    `;
  }

  // Filtrar y renderizar lista de noticias
  function renderNewsList() {
    if (!elements.newsGrid) return;

    let filtered = NEWS_DATA;

    // Filtro por categoría
    if (state.currentCategory !== 'all') {
      filtered = filtered.filter(item => item.category === state.currentCategory);
    }

    // Filtro por búsqueda
    if (state.searchQuery.trim() !== '') {
      const q = state.searchQuery.toLowerCase();
      filtered = filtered.filter(item => 
        item.title.toLowerCase().includes(q) ||
        item.summary.toLowerCase().includes(q) ||
        item.author.toLowerCase().includes(q) ||
        item.categoryName.toLowerCase().includes(q)
      );
    }

    if (filtered.length === 0) {
      elements.newsGrid.innerHTML = `
        <div class="col-span-full py-16 text-center">
          <div class="w-20 h-20 mx-auto rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-3xl text-cyan-400 mb-4 animate-bounce">
            <i class="fa-solid fa-compass"></i>
          </div>
          <h3 class="text-xl font-bold text-white mb-2">No se encontraron noticias</h3>
          <p class="text-slate-400 text-sm max-w-md mx-auto mb-6">
            Intenta con otra palabra clave o selecciona la categoría "Todos" para explorar toda la edición.
          </p>
          <button onclick="window.resetFilter()" class="px-5 py-2 rounded-xl bg-slate-800 text-cyan-400 border border-cyan-500/40 hover:bg-cyan-500/10 text-sm transition-all">
            Restablecer Filtros
          </button>
        </div>
      `;
      return;
    }

    elements.newsGrid.innerHTML = filtered.map(news => {
      const isBookmarked = state.bookmarks.includes(news.id);
      return `
        <article class="news-card group flex flex-col bg-slate-800/80 rounded-2xl overflow-hidden border border-slate-700/60 shadow-lg hover:border-cyan-500/50 hover:shadow-cyan-500/10 transition-all duration-300">
          <div class="relative h-48 overflow-hidden">
            <img src="${news.image}" alt="${news.title}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy">
            <div class="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-transparent to-transparent"></div>
            <span class="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-semibold bg-slate-900/80 backdrop-blur-md text-cyan-400 border border-cyan-500/30">
              ${news.categoryName}
            </span>
            <span class="absolute bottom-3 right-3 text-xs text-slate-300 bg-slate-950/70 px-2 py-0.5 rounded backdrop-blur-sm flex items-center gap-1">
              <i class="fa-regular fa-clock text-[10px]"></i> ${news.readTime}
            </span>
          </div>

          <div class="p-5 flex-1 flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between text-xs text-slate-400 mb-2.5">
                <span>${news.date}</span>
                <span class="flex items-center gap-1 text-slate-400">
                  <i class="fa-solid fa-eye text-[11px] text-cyan-400/80"></i> ${news.views}
                </span>
              </div>

              <h3 onclick="window.openArticleModal(${news.id})" class="font-bold text-lg text-white mb-2.5 line-clamp-2 leading-snug cursor-pointer group-hover:text-cyan-400 transition-colors">
                ${news.title}
              </h3>

              <p class="text-slate-300 text-xs sm:text-sm line-clamp-3 leading-relaxed mb-4">
                ${news.summary}
              </p>
            </div>

            <div class="pt-4 border-t border-slate-700/50 flex items-center justify-between text-xs">
              <div class="flex items-center gap-2">
                <div class="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center font-bold text-xs text-cyan-400">
                  ${news.author.charAt(0)}
                </div>
                <span class="text-slate-300 font-medium truncate max-w-[120px]">${news.author}</span>
              </div>

              <div class="flex items-center gap-2">
                <button onclick="window.toggleBookmark(${news.id})" class="p-2 rounded-lg bg-slate-700/50 text-slate-300 hover:text-cyan-400 transition-colors" title="Guardar">
                  <i class="${isBookmarked ? 'fa-solid text-cyan-400' : 'fa-regular'} fa-bookmark text-sm"></i>
                </button>
                <button onclick="window.openArticleModal(${news.id})" class="px-3 py-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950 font-semibold border border-cyan-500/30 transition-all flex items-center gap-1">
                  <span>Leer</span>
                  <i class="fa-solid fa-arrow-right text-[10px]"></i>
                </button>
              </div>
            </div>
          </div>
        </article>
      `;
    }).join('');
  }

  /* ==========================================================================
     MODAL DE LECTURA Y DETALLES DE NOTICIA
     ========================================================================== */

  window.openArticleModal = (articleId) => {
    const article = NEWS_DATA.find(n => n.id === articleId);
    if (!article) return;

    state.currentArticle = article;
    state.fontSizeMultiplier = 1;

    // Poblar modal
    elements.modalCategory.textContent = article.categoryName;
    elements.modalTitle.textContent = article.title;
    elements.modalAuthor.textContent = article.author;
    elements.modalAuthorRole.textContent = article.authorRole;
    elements.modalDate.textContent = article.date;
    elements.modalReadTime.textContent = article.readTime;
    elements.modalImage.src = article.image;
    elements.modalImage.alt = article.title;
    
    // Contenido formateado en párrafos
    const formattedParagraphs = article.content
      .split('\n\n')
      .map(p => `<p class="mb-4 text-slate-300 leading-relaxed text-base">${p}</p>`)
      .join('');
    elements.modalContent.innerHTML = formattedParagraphs;
    applyFontSize();

    // Actualizar contadores
    elements.modalLikeCount.textContent = article.likes;
    elements.modalClapCount.textContent = article.claps;

    // Estado del botón de guardar
    updateModalBookmarkBtn();

    // Renderizar comentarios
    renderComments();

    // Detener síntesis de voz previa si estuviera activa
    stopSpeechSynthesis();

    // Mostrar modal con animación
    elements.articleModal.classList.remove('hidden');
    elements.articleModal.classList.add('flex');
    document.body.classList.add('overflow-hidden');
  };

  window.closeArticleModal = () => {
    stopSpeechSynthesis();
    elements.articleModal.classList.add('hidden');
    elements.articleModal.classList.remove('flex');
    document.body.classList.remove('overflow-hidden');
  };

  function applyFontSize() {
    elements.modalContent.style.fontSize = `${1 * state.fontSizeMultiplier}rem`;
    elements.modalContent.style.lineHeight = `${1.7 * state.fontSizeMultiplier}`;
  }

  // Comentarios interactivos
  function renderComments() {
    if (!elements.commentsList || !state.currentArticle) return;
    const comments = state.currentArticle.comments || [];
    
    if (comments.length === 0) {
      elements.commentsList.innerHTML = `
        <p class="text-sm text-slate-400 italic py-4">Sé el primero en compartir tu opinión sobre este reportaje.</p>
      `;
      return;
    }

    elements.commentsList.innerHTML = comments.map(c => `
      <div class="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 text-sm">
        <div class="flex items-center justify-between mb-1.5">
          <div class="flex items-center gap-2">
            <span class="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center">
              ${c.user.charAt(0)}
            </span>
            <span class="font-bold text-white text-xs">${c.user}</span>
          </div>
          <span class="text-[11px] text-slate-500">${c.time}</span>
        </div>
        <p class="text-slate-300 text-xs sm:text-sm pl-8">${c.text}</p>
      </div>
    `).join('');
  }

  /* ==========================================================================
     SÍNTESIS DE VOZ INTERACTIVA (Escuchar Noticia)
     ========================================================================== */

  function toggleSpeechSynthesis() {
    if (!('speechSynthesis' in window) || !state.currentArticle) {
      showToast('Tu navegador no soporta síntesis de voz.');
      return;
    }

    if (state.isSpeaking) {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
        updateTtsUi(true);
      } else {
        window.speechSynthesis.pause();
        updateTtsUi(false, true);
      }
    } else {
      const fullText = `${state.currentArticle.title}. ${state.currentArticle.content}`;
      state.speechSynthesisUtterance = new SpeechSynthesisUtterance(fullText);
      state.speechSynthesisUtterance.lang = 'es-ES';
      state.speechSynthesisUtterance.rate = 1.0;

      state.speechSynthesisUtterance.onstart = () => {
        state.isSpeaking = true;
        updateTtsUi(true);
      };

      state.speechSynthesisUtterance.onend = () => {
        state.isSpeaking = false;
        updateTtsUi(false);
      };

      state.speechSynthesisUtterance.onerror = () => {
        state.isSpeaking = false;
        updateTtsUi(false);
      };

      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(state.speechSynthesisUtterance);
    }
  }

  function stopSpeechSynthesis() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    state.isSpeaking = false;
    updateTtsUi(false);
  }

  function updateTtsUi(speaking, paused = false) {
    if (!elements.modalTtsBtn) return;
    if (speaking) {
      elements.modalTtsBtn.innerHTML = '<i class="fa-solid fa-pause text-cyan-400 animate-pulse"></i><span>Pausar Lectura</span>';
      elements.modalTtsBtn.classList.add('border-cyan-500', 'bg-cyan-500/10');
    } else if (paused) {
      elements.modalTtsBtn.innerHTML = '<i class="fa-solid fa-play text-cyan-400"></i><span>Reanudar Lectura</span>';
    } else {
      elements.modalTtsBtn.innerHTML = '<i class="fa-solid fa-volume-high text-cyan-400"></i><span>Escuchar Noticia</span>';
      elements.modalTtsBtn.classList.remove('border-cyan-500', 'bg-cyan-500/10');
    }
  }

  /* ==========================================================================
     BOOKMARKS / NOTICIAS GUARDADAS
     ========================================================================== */

  window.toggleBookmark = (id) => {
    const index = state.bookmarks.indexOf(id);
    if (index === -1) {
      state.bookmarks.push(id);
      showToast('Artículo añadido a tus marcadores guardados.');
    } else {
      state.bookmarks.splice(index, 1);
      showToast('Artículo eliminado de tus marcadores.');
    }

    storage.setBookmarks(state.bookmarks);
    updateBookmarkBadge();
    renderFeaturedNews();
    renderNewsList();
    updateModalBookmarkBtn();
    renderBookmarksList();
  };

  function updateBookmarkBadge() {
    if (elements.bookmarkCount) {
      elements.bookmarkCount.textContent = state.bookmarks.length;
      elements.bookmarkCount.classList.toggle('hidden', state.bookmarks.length === 0);
    }
  }

  function updateModalBookmarkBtn() {
    if (!elements.modalBookmarkBtn || !state.currentArticle) return;
    const isBookmarked = state.bookmarks.includes(state.currentArticle.id);
    elements.modalBookmarkBtn.innerHTML = isBookmarked
      ? '<i class="fa-solid fa-bookmark text-cyan-400"></i>'
      : '<i class="fa-regular fa-bookmark"></i>';
  }

  function renderBookmarksList() {
    if (!elements.bookmarksList) return;
    const saved = NEWS_DATA.filter(n => state.bookmarks.includes(n.id));

    if (saved.length === 0) {
      elements.bookmarksList.innerHTML = `
        <div class="py-12 text-center text-slate-400">
          <i class="fa-regular fa-bookmark text-4xl mb-3 text-slate-600 block"></i>
          <p class="text-sm">Aún no has guardado ninguna noticia para leer después.</p>
        </div>
      `;
      return;
    }

    elements.bookmarksList.innerHTML = saved.map(item => `
      <div class="flex items-center justify-between p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-cyan-500/40 transition-colors">
        <div class="cursor-pointer flex-1 mr-3" onclick="window.closeBookmarksModal(); window.openArticleModal(${item.id})">
          <span class="text-xs text-cyan-400 font-semibold">${item.categoryName}</span>
          <h4 class="text-sm font-bold text-white line-clamp-1 hover:text-cyan-400 transition-colors">${item.title}</h4>
          <span class="text-xs text-slate-400">${item.date}</span>
        </div>
        <button onclick="window.toggleBookmark(${item.id})" class="p-2 text-rose-400 hover:text-rose-300" title="Eliminar de guardados">
          <i class="fa-solid fa-trash-can text-sm"></i>
        </button>
      </div>
    `).join('');
  }

  window.openBookmarksModal = () => {
    renderBookmarksList();
    elements.bookmarksModal.classList.remove('hidden');
    elements.bookmarksModal.classList.add('flex');
  };

  window.closeBookmarksModal = () => {
    elements.bookmarksModal.classList.add('hidden');
    elements.bookmarksModal.classList.remove('flex');
  };

  /* ==========================================================================
     TEMA Y NOTIFICACIONES
     ========================================================================== */

  function applyTheme(theme) {
    state.theme = theme;
    storage.setTheme(theme);
    const html = document.documentElement;

    if (theme === 'light') {
      html.classList.remove('dark');
      html.classList.add('light');
      if (elements.themeIcon) elements.themeIcon.className = 'fa-solid fa-moon text-cyan-600';
    } else {
      html.classList.remove('light');
      html.classList.add('dark');
      if (elements.themeIcon) elements.themeIcon.className = 'fa-solid fa-sun text-amber-400';
    }
  }

  function toggleTheme() {
    const newTheme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme(newTheme);
  }

  function showToast(message) {
    if (!elements.toastNotification || !elements.toastMessage) return;
    elements.toastMessage.textContent = message;
    elements.toastNotification.classList.remove('opacity-0', 'translate-y-4', 'pointer-events-none');
    elements.toastNotification.classList.add('opacity-100', 'translate-y-0');

    setTimeout(() => {
      elements.toastNotification.classList.remove('opacity-100', 'translate-y-0');
      elements.toastNotification.classList.add('opacity-0', 'translate-y-4', 'pointer-events-none');
    }, 3200);
  }

  window.resetFilter = () => {
    state.currentCategory = 'all';
    state.searchQuery = '';
    if (elements.searchInput) elements.searchInput.value = '';
    elements.categoryButtons.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.category === 'all');
    });
    renderNewsList();
  };

  /* ==========================================================================
     CONFIGURACIÓN DE EVENT LISTENERS
     ========================================================================== */

  function setupEventListeners() {
    // Filtros de categoría
    elements.categoryButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        elements.categoryButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.currentCategory = btn.dataset.category;
        renderNewsList();
      });
    });

    // Búsqueda en tiempo real
    if (elements.searchInput) {
      elements.searchInput.addEventListener('input', (e) => {
        state.searchQuery = e.target.value;
        renderNewsList();
      });
    }

    // Toggle de tema
    if (elements.themeToggleBtn) {
      elements.themeToggleBtn.addEventListener('click', toggleTheme);
    }

    // Modal de Marcadores
    if (elements.bookmarkBtn) {
      elements.bookmarkBtn.addEventListener('click', window.openBookmarksModal);
    }
    if (elements.closeBookmarksBtn) {
      elements.closeBookmarksBtn.addEventListener('click', window.closeBookmarksModal);
    }

    // Modal de Noticia
    if (elements.closeArticleBtn) {
      elements.closeArticleBtn.addEventListener('click', window.closeArticleModal);
    }

    // Cerrar modales con Escape
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        window.closeArticleModal();
        window.closeBookmarksModal();
      }
    });

    // Cerrar al hacer clic fuera del contenido (backdrop)
    elements.articleModal?.addEventListener('click', (e) => {
      if (e.target === elements.articleModal) window.closeArticleModal();
    });
    elements.bookmarksModal?.addEventListener('click', (e) => {
      if (e.target === elements.bookmarksModal) window.closeBookmarksModal();
    });

    // Likes & Claps en modal
    if (elements.modalLikeBtn) {
      elements.modalLikeBtn.addEventListener('click', () => {
        if (!state.currentArticle) return;
        state.currentArticle.likes++;
        elements.modalLikeCount.textContent = state.currentArticle.likes;
        elements.modalLikeBtn.classList.add('scale-125', 'text-rose-500');
        setTimeout(() => elements.modalLikeBtn.classList.remove('scale-125'), 200);
      });
    }

    if (elements.modalClapBtn) {
      elements.modalClapBtn.addEventListener('click', () => {
        if (!state.currentArticle) return;
        state.currentArticle.claps++;
        elements.modalClapCount.textContent = state.currentArticle.claps;
        elements.modalClapBtn.classList.add('scale-125', 'text-amber-400');
        setTimeout(() => elements.modalClapBtn.classList.remove('scale-125'), 200);
      });
    }

    // Guardar desde modal
    if (elements.modalBookmarkBtn) {
      elements.modalBookmarkBtn.addEventListener('click', () => {
        if (state.currentArticle) window.toggleBookmark(state.currentArticle.id);
      });
    }

    // TTS
    if (elements.modalTtsBtn) {
      elements.modalTtsBtn.addEventListener('click', toggleSpeechSynthesis);
    }

    // Compartir
    if (elements.modalShareBtn) {
      elements.modalShareBtn.addEventListener('click', () => {
        if (!state.currentArticle) return;
        if (navigator.share) {
          navigator.share({
            title: state.currentArticle.title,
            text: state.currentArticle.summary,
            url: window.location.href
          }).catch(() => {});
        } else {
          navigator.clipboard.writeText(window.location.href);
          showToast('¡Enlace de la noticia copiado al portapapeles!');
        }
      });
    }

    // Ajuste de tipografía
    if (elements.fontIncreaseBtn) {
      elements.fontIncreaseBtn.addEventListener('click', () => {
        if (state.fontSizeMultiplier < 1.4) {
          state.fontSizeMultiplier += 0.1;
          applyFontSize();
        }
      });
    }

    if (elements.fontDecreaseBtn) {
      elements.fontDecreaseBtn.addEventListener('click', () => {
        if (state.fontSizeMultiplier > 0.8) {
          state.fontSizeMultiplier -= 0.1;
          applyFontSize();
        }
      });
    }

    // Formulario de comentarios
    if (elements.commentForm) {
      elements.commentForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = elements.commentInput.value.trim();
        const user = elements.commentUserInput.value.trim() || 'Lector Anónimo';
        if (!text || !state.currentArticle) return;

        state.currentArticle.comments = state.currentArticle.comments || [];
        state.currentArticle.comments.unshift({
          user: user,
          time: 'Justo ahora',
          text: text
        });

        elements.commentInput.value = '';
        renderComments();
        showToast('¡Tu comentario ha sido publicado!');
      });
    }

    // Newsletter
    if (elements.newsletterForm) {
      elements.newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = elements.newsletterEmail.value.trim();
        if (email) {
          showToast(`¡Gracias! Has sido suscrito con: ${email}`);
          elements.newsletterEmail.value = '';
        }
      });
    }

    // Controles del Modelo 3D
    if (state.threeInstance) {
      // Modos
      elements.modelGlobeBtn?.addEventListener('click', () => {
        state.threeInstance.setMode('globe');
        setActiveBtn([elements.modelGlobeBtn, elements.modelCubeBtn, elements.modelPrismBtn], elements.modelGlobeBtn);
        showToast('Modo 3D: HoloGlobo Interactivo');
      });

      elements.modelCubeBtn?.addEventListener('click', () => {
        state.threeInstance.setMode('cube');
        setActiveBtn([elements.modelGlobeBtn, elements.modelCubeBtn, elements.modelPrismBtn], elements.modelCubeBtn);
        showToast('Modo 3D: Cubo Isométrico de Noticias');
      });

      elements.modelPrismBtn?.addEventListener('click', () => {
        state.threeInstance.setMode('prism');
        setActiveBtn([elements.modelGlobeBtn, elements.modelCubeBtn, elements.modelPrismBtn], elements.modelPrismBtn);
        showToast('Modo 3D: Prisma Cristalino');
      });

      // Temas de Color 3D
      elements.themeCyanBtn?.addEventListener('click', () => {
        state.threeInstance.setTheme('cyan');
        setActiveBtn([elements.themeCyanBtn, elements.themeAmberBtn, elements.themePurpleBtn], elements.themeCyanBtn);
      });

      elements.themeAmberBtn?.addEventListener('click', () => {
        state.threeInstance.setTheme('amber');
        setActiveBtn([elements.themeCyanBtn, elements.themeAmberBtn, elements.themePurpleBtn], elements.themeAmberBtn);
      });

      elements.themePurpleBtn?.addEventListener('click', () => {
        state.threeInstance.setTheme('purple');
        setActiveBtn([elements.themeCyanBtn, elements.themeAmberBtn, elements.themePurpleBtn], elements.themePurpleBtn);
      });

      // Velocidad
      elements.speedSlider?.addEventListener('input', (e) => {
        const val = e.target.value;
        state.threeInstance.setSpeed(val);
        if (elements.speedLabel) elements.speedLabel.textContent = `${parseFloat(val * 100).toFixed(0)}%`;
      });
    }

    // Trigger para el Icono Móvil 3D Flotante
    elements.floating3dTrigger?.addEventListener('click', () => {
      elements.hero3dCard?.scrollIntoView({ behavior: 'smooth' });
      state.threeInstance?.pulseAnimation();
    });
  }

  function setActiveBtn(group, activeBtn) {
    group.forEach(btn => {
      if (!btn) return;
      btn.classList.remove('bg-cyan-500', 'text-slate-950', 'border-cyan-400');
      btn.classList.add('bg-slate-800', 'text-slate-300', 'border-slate-700');
    });
    if (activeBtn) {
      activeBtn.classList.remove('bg-slate-800', 'text-slate-300', 'border-slate-700');
      activeBtn.classList.add('bg-cyan-500', 'text-slate-950', 'border-cyan-400');
    }
  }
});
