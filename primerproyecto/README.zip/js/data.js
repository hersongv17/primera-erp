// Base de datos de noticias en español
const NEWS_DATA = [
  {
    id: 1,
    title: "La Inteligencia Artificial revoluciona el periodismo inmersivo y el análisis de datos en tiempo real",
    category: "tecnologia",
    categoryName: "Tecnología",
    summary: "Nuevas herramientas generativas permiten a las salas de redacción procesar millones de datos en segundos y crear experiencias visuales interactivas en 3D.",
    content: `La convergencia entre la inteligencia artificial generativa y las tecnologías 3D está transformando radicalmente la forma en que consumimos información. Los medios digitales de última generación no solo presentan texto e imágenes estáticas, sino entornos informativos vivos donde el lector puede explorar infografías volumétricas y simulaciones dinámicas.

Expertos de los principales laboratorios de innovación periodística señalan que esta evolución democratiza el acceso a análisis complejos. Mediante algoritmos de síntesis y renderizado acelerado por hardware, los reportajes de investigación ahora integran modelos tridimensionales interactivos que permiten inspeccionar desde misiones espaciales hasta desgloses presupuestarios con precisión milimétrica.

Además, la personalización ética de contenidos garantiza que cada usuario reciba perspectivas contextualizadas sin caer en cámaras de eco, marcando el inicio de una nueva era para el periodismo digital global.`,
    author: "Elena Rostova",
    authorRole: "Editora de Innovación y Tecnología",
    date: "27 Oct 2026",
    readTime: "4 min",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
    featured: true,
    views: "18.4K",
    likes: 342,
    claps: 128,
    comments: [
      { user: "Carlos M.", time: "Hace 2 horas", text: "Increíble la integración 3D en las noticias. Facilita entender temas complejos." },
      { user: "Sofía Gómez", time: "Hace 4 horas", text: "El futuro de los medios interactivos ya está aquí." }
    ]
  },
  {
    id: 2,
    title: "Descubren un nuevo exoplaneta habitable con atmósfera densa mediante el telescopio espacial",
    category: "ciencia",
    categoryName: "Ciencia",
    summary: "Astrofísicos internacionales confirman indicios de vapor de agua y compuestos orgánicos en un sistema estelar a 48 años luz.",
    content: `Un equipo internacional de astrofísicos ha confirmado el hallazgo de un prometedor exoplaneta rocoso orbitando en la zona habitable de su estrella anfitriona. Los análisis espectrales revelan una atmósfera densa compuesta por nitrógeno, trazas de dióxido de carbono y vapor de agua.

El cuerpo celeste, denominado provisionalmente 'Aethelgard-4b', posee una masa 1.3 veces superior a la Tierra, lo que le confiere una gravedad superficial cómoda para hipotéticas exploraciones robóticas. Las observaciones continuarán durante los próximos meses con espectroscopia infrarroja para determinar la presencia de biofirmas adicionales.`,
    author: "Dr. Marcos Valdés",
    authorRole: "Astrofísico y Divulgador",
    date: "27 Oct 2026",
    readTime: "6 min",
    image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80",
    featured: false,
    views: "24.1K",
    likes: 819,
    claps: 412,
    comments: [
      { user: "Laura Vega", time: "Hace 1 hora", text: "Cada hallazgo nos acerca más a responder la gran pregunta." }
    ]
  },
  {
    id: 3,
    title: "Mercados globales responden con optimismo ante el nuevo tratado de energías renovables",
    category: "economia",
    categoryName: "Economía",
    summary: "Las bolsas europeas y asiáticas registran alzas históricas impulsadas por inversiones en hidrógeno verde y baterías de estado sólido.",
    content: `La firma del nuevo pacto multilateral para la transición energética ha desencadenado un repunte masivo en los principales índices bursátiles. Las compañías especializadas en almacenamiento en red y tecnologías solares de perovskita han liderado las ganancias.

Analistas de Wall Street y Frankfurt coinciden en que los incentivos fiscales y el marco regulatorio unificado ofrecen la certeza jurídica necesaria para canalizar billones de dólares hacia infraestructuras sostenibles durante la próxima década.`,
    author: "Patricia Méndez",
    authorRole: "Analista Financiera Senior",
    date: "26 Oct 2026",
    readTime: "5 min",
    image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&w=1200&q=80",
    featured: false,
    views: "12.7K",
    likes: 195,
    claps: 64,
    comments: []
  },
  {
    id: 4,
    title: "Arquitectura biológica: rascacielos que purifican el aire urbano y generan su propia energía",
    category: "innovacion",
    categoryName: "Innovación",
    summary: "Nuevas torres bioclimáticas en Singapur y Tokio utilizan fachadas vivas con microalgas para capturar carbono y generar electricidad.",
    content: `La simbiosis entre biología y diseño estructural está redefiniendo el horizonte urbano. En las principales metrópolis de Asia, rascacielos dotados de bioreactores de microalgas integrados en sus cerramientos de vidrio absorben hasta 10 veces más CO2 que un bosque de superficie equivalente.

El subproducto de este proceso —biomasa rica en nutrientes— se transforma in situ en biogás y biocombustible para alimentar la climatización y los sistemas de iluminación del propio edificio, alcanzando la categoría de huella de carbono negativa.`,
    author: "Rodrigo Chen",
    authorRole: "Corresponsal de Arquitectura y Urbanismo",
    date: "26 Oct 2026",
    readTime: "4 min",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80",
    featured: false,
    views: "9.3K",
    likes: 274,
    claps: 92,
    comments: []
  },
  {
    id: 5,
    title: "Avance médico: Nanorobots programables logran eliminar células tumorales sin dañar tejido sano",
    category: "salud",
    categoryName: "Salud",
    summary: "Ensayos clínicos de fase II demuestran una eficacia del 94% en tratamientos dirigidos con nanopartículas guiadas por campos magnéticos.",
    content: `Científicos del Centro Oncológico Avanzado han presentado resultados sin precedentes en el tratamiento selectivo de neoplasias. Mediante nanorobots de ADN plegado y núcleos ferromagnéticos, los fármacos de quimioterapia son transportados directamente al interior de las células malignas.

Este método de 'entrega milimétrica' previene los efectos adversos clásicos de los tratamientos tradicionales, abriendo la puerta a terapias ambulatorias de rápida recuperación con mínima toxicidad sistémica.`,
    author: "Dra. Valeria Campos",
    authorRole: "Especialista en Nanomedicina",
    date: "25 Oct 2026",
    readTime: "7 min",
    image: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=1200&q=80",
    featured: false,
    views: "31.5K",
    likes: 1204,
    claps: 590,
    comments: [
      { user: "Andrés Silva", time: "Ayer", text: "Un hito que cambiará millones de vidas. Felicitaciones al equipo médico." }
    ]
  },
  {
    id: 6,
    title: "La final del Campeonato Mundial de E-Sports reúne a más de 80 millones de espectadores en directo",
    category: "cultura",
    categoryName: "Cultura & Ocio",
    summary: "El evento transmitido en hologramas 3D y realidad aumentada bate récords históricos de audiencia global.",
    content: `La cúspide del deporte electrónico celebró su final más vista en la historia. Los estadios virtuales sincronizados en Tokio, Seúl y Los Ángeles combinaron proyecciones volumétricas a escala real donde los avatares de los jugadores interactuaban en arenas cinemáticas.

Marcas globales y plataformas de streaming han consolidado este ecosistema como uno de los motores culturales y publicitarios más dinámicos entre las nuevas generaciones de nativos digitales.`,
    author: "Matías Morales",
    authorRole: "Cronista de Cultura Digital",
    date: "25 Oct 2026",
    readTime: "3 min",
    image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80",
    featured: false,
    views: "44.9K",
    likes: 1530,
    claps: 810,
    comments: []
  }
];

const BREAKING_NEWS = [
  "🚨 ÚLTIMA HORA: Misión Artemis IV aterriza con éxito en el polo sur lunar con equipo científico internacional.",
  "⚡ MERCADOS: El índice tecnológico repunta +3.2% tras anuncios sobre supercomputación cuántica.",
  "🌱 CLIMA: Alianza global logra acuerdo vinculante para proteger el 40% de los océanos mundiales.",
  "🛰️ CIENCIA: Telescopio orbital detecta señales de radio coherentes en una galaxia vecina."
];

