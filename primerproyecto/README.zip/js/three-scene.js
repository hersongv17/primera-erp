/**
 * Escena 3D Interactiva con Three.js para la Web de Noticias
 * Incluye un icono 3D móvil interactivo con múltiples modos:
 * 1. HoloGlobo 3D (Globo terráqueo holográfico con anillos orbitales y satélites)
 * 2. Cubo de Noticias 3D (Cubo isométrico con texturas tipográficas y resplandor)
 * 3. Prisma Holográfico 3D (Prisma cristalino con partículas orbitales)
 */

class Interactive3DNewsIcon {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    if (!this.container) return;

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.mainGroup = null;
    this.orbitGroup = null;
    this.particles = null;

    // Estados y animaciones
    this.mouseX = 0;
    this.mouseY = 0;
    this.targetRotationX = 0;
    this.targetRotationY = 0;
    this.currentMode = 'globe'; // 'globe', 'cube', 'prism'
    this.rotationSpeed = 0.008;
    this.isDragging = false;
    this.previousMousePosition = { x: 0, y: 0 };
    this.colorThemes = {
      cyan: { primary: 0x00f2fe, secondary: 0x4facfe, glow: 0x00e5ff },
      amber: { primary: 0xffaa00, secondary: 0xff6a00, glow: 0xffd200 },
      purple: { primary: 0xd946ef, secondary: 0x8b5cf6, glow: 0xc084fc }
    };
    this.activeTheme = 'cyan';

    this.init();
    this.setupListeners();
    this.animate();
  }

  init() {
    const width = this.container.clientWidth || 360;
    const height = this.container.clientHeight || 360;

    // Escena
    this.scene = new THREE.Scene();

    // Cámara
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    this.camera.position.z = 7;

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.2;
    this.container.appendChild(this.renderer.domElement);

    // Grupo principal para el icono 3D
    this.mainGroup = new THREE.Group();
    this.orbitGroup = new THREE.Group();
    this.mainGroup.add(this.orbitGroup);
    this.scene.add(this.mainGroup);

    // Luces
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    this.scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x00f2fe, 2.5);
    dirLight1.position.set(5, 5, 5);
    this.scene.add(dirLight1);
    this.dirLight1 = dirLight1;

    const dirLight2 = new THREE.DirectionalLight(0xec4899, 2);
    dirLight2.position.set(-5, -5, -3);
    this.scene.add(dirLight2);
    this.dirLight2 = dirLight2;

    const pointLight = new THREE.PointLight(0xffffff, 3, 20);
    pointLight.position.set(0, 0, 4);
    this.scene.add(pointLight);

    // Partículas ambientales de noticias (datos en el aire)
    this.createNewsParticles();

    // Construir el modelo inicial
    this.buildGlobeModel();
  }

  // --- MODELO 1: GLOBO TERRÁQUEO HOLOGRÁFICO DE NOTICIAS ---
  buildGlobeModel() {
    this.clearMainGroup();
    const theme = this.colorThemes[this.activeTheme];

    // 1. Núcleo central brillante
    const coreGeo = new THREE.SphereGeometry(1.4, 32, 32);
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0x051329,
      roughness: 0.2,
      metalness: 0.8,
      emissive: theme.secondary,
      emissiveIntensity: 0.15
    });
    const coreSphere = new THREE.Mesh(coreGeo, coreMat);
    this.mainGroup.add(coreSphere);

    // 2. Malla wireframe de meridianos y paralelos
    const wireGeo = new THREE.SphereGeometry(1.44, 24, 24);
    const wireMat = new THREE.MeshBasicMaterial({
      color: theme.primary,
      wireframe: true,
      transparent: true,
      opacity: 0.35
    });
    const wireSphere = new THREE.Mesh(wireGeo, wireMat);
    this.mainGroup.add(wireSphere);

    // 3. Puntos flotantes de continentes / Nodos de información
    const pointsCount = 400;
    const pointsGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(pointsCount * 3);
    for (let i = 0; i < pointsCount; i++) {
      const phi = Math.acos(-1 + (2 * i) / pointsCount);
      const theta = Math.sqrt(pointsCount * Math.PI) * phi;
      const radius = 1.46 + Math.random() * 0.05;

      positions[i * 3] = radius * Math.cos(theta) * Math.sin(phi);
      positions[i * 3 + 1] = radius * Math.sin(theta) * Math.sin(phi);
      positions[i * 3 + 2] = radius * Math.cos(phi);
    }
    pointsGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const pointsMat = new THREE.PointsMaterial({
      color: theme.glow,
      size: 0.06,
      transparent: true,
      opacity: 0.8
    });
    const pointsMesh = new THREE.Points(pointsGeo, pointsMat);
    this.mainGroup.add(pointsMesh);

    // 4. Anillo orbital ecuatorial exterior (Flujo de noticias 24/7)
    const ringGeo = new THREE.TorusGeometry(2.1, 0.03, 16, 100);
    const ringMat = new THREE.MeshStandardMaterial({
      color: theme.primary,
      emissive: theme.primary,
      emissiveIntensity: 0.6,
      roughness: 0.1,
      metalness: 0.9
    });
    const ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = Math.PI / 3;
    ringMesh.rotation.y = Math.PI / 6;
    this.orbitRing1 = ringMesh;
    this.mainGroup.add(ringMesh);

    // Segundo anillo orbital inclinado
    const ringGeo2 = new THREE.TorusGeometry(2.35, 0.02, 16, 100);
    const ringMat2 = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.3
    });
    const ringMesh2 = new THREE.Mesh(ringGeo2, ringMat2);
    ringMesh2.rotation.x = -Math.PI / 4;
    ringMesh2.rotation.z = Math.PI / 5;
    this.orbitRing2 = ringMesh2;
    this.mainGroup.add(ringMesh2);

    // 5. Balizas satelitales orbitantes (Nodos de información en directo)
    this.satellites = [];
    for (let i = 0; i < 3; i++) {
      const satGroup = new THREE.Group();
      const satGeo = new THREE.OctahedronGeometry(0.12, 0);
      const satMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        emissive: theme.glow,
        emissiveIntensity: 1
      });
      const sat = new THREE.Mesh(satGeo, satMat);
      sat.position.set(Math.cos((i * Math.PI * 2) / 3) * 2.2, 0, Math.sin((i * Math.PI * 2) / 3) * 2.2);
      satGroup.add(sat);
      satGroup.rotation.x = (i * Math.PI) / 4;
      satGroup.rotation.y = (i * Math.PI) / 3;
      this.orbitGroup.add(satGroup);
      this.satellites.push({ group: satGroup, speed: 0.015 + i * 0.005 });
    }
  }

  // --- MODELO 2: CUBO ISOMÉTRICO DE NOTICIAS ---
  buildCubeModel() {
    this.clearMainGroup();
    const theme = this.colorThemes[this.activeTheme];

    // Cubo principal biselado o segmentado
    const cubeGeo = new THREE.BoxGeometry(2.0, 2.0, 2.0);
    
    // Generar textura dinámica de prensa para las caras
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#0a1128';
    ctx.fillRect(0, 0, 512, 512);
    ctx.fillStyle = '#00f2fe';
    ctx.font = 'bold 50px sans-serif';
    ctx.fillText('NOVA PRESS', 60, 100);
    ctx.fillStyle = '#ffffff';
    ctx.font = '28px sans-serif';
    ctx.fillText('EDICIÓN DIGITAL 3D', 60, 160);
    ctx.fillStyle = '#64748b';
    for (let y = 220; y < 450; y += 35) {
      ctx.fillRect(60, y, 390 * (Math.sin(y) * 0.2 + 0.8), 12);
    }
    const texture = new THREE.CanvasTexture(canvas);

    const cubeMat = new THREE.MeshStandardMaterial({
      map: texture,
      roughness: 0.3,
      metalness: 0.7,
      emissive: theme.secondary,
      emissiveIntensity: 0.1
    });

    const cubeMesh = new THREE.Mesh(cubeGeo, cubeMat);
    this.mainGroup.add(cubeMesh);

    // Marco exterior de neón
    const edgeGeo = new THREE.BoxGeometry(2.1, 2.1, 2.1);
    const edgeMat = new THREE.MeshBasicMaterial({
      color: theme.primary,
      wireframe: true,
      transparent: true,
      opacity: 0.6
    });
    const edgeMesh = new THREE.Mesh(edgeGeo, edgeMat);
    this.mainGroup.add(edgeMesh);

    // Elementos flotantes alrededor del cubo
    for (let i = 0; i < 4; i++) {
      const tagGeo = new THREE.BoxGeometry(0.5, 0.15, 0.05);
      const tagMat = new THREE.MeshStandardMaterial({
        color: theme.glow,
        emissive: theme.primary,
        emissiveIntensity: 0.8
      });
      const tag = new THREE.Mesh(tagGeo, tagMat);
      const angle = (i * Math.PI) / 2;
      tag.position.set(Math.cos(angle) * 1.8, Math.sin(angle) * 1.8, (i % 2 === 0 ? 0.6 : -0.6));
      this.mainGroup.add(tag);
    }
  }

  // --- MODELO 3: PRISMA DE INFORMACIÓN HOLOGRÁFICO ---
  buildPrismModel() {
    this.clearMainGroup();
    const theme = this.colorThemes[this.activeTheme];

    // Geometría de prisma piramidal gemelo
    const prismGeo = new THREE.OctahedronGeometry(1.6, 0);
    const prismMat = new THREE.MeshPhysicalMaterial({
      color: theme.primary,
      emissive: theme.secondary,
      emissiveIntensity: 0.2,
      roughness: 0.1,
      metalness: 0.1,
      transmission: 0.85,
      thickness: 1.2,
      transparent: true,
      opacity: 0.95
    });

    const prism = new THREE.Mesh(prismGeo, prismMat);
    this.mainGroup.add(prism);

    // Malla interna con pulso
    const innerGeo = new THREE.IcosahedronGeometry(0.8, 1);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      wireframe: true
    });
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    this.mainGroup.add(innerMesh);

    // Anillo vertical giratorio
    const ringGeo = new THREE.TorusGeometry(2.0, 0.04, 16, 80);
    const ringMat = new THREE.MeshStandardMaterial({
      color: theme.glow,
      emissive: theme.primary,
      emissiveIntensity: 1
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    this.orbitRing1 = ring;
    this.mainGroup.add(ring);
  }

  // Partículas de fondo simulando ondas de datos
  createNewsParticles() {
    const particleCount = 200;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const scales = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 14;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 14;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10;
      scales[i] = Math.random() * 2 + 1;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('scale', new THREE.BufferAttribute(scales, 1));

    const material = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.05,
      transparent: true,
      opacity: 0.5,
      blending: THREE.AdditiveBlending
    });

    this.particles = new THREE.Points(geometry, material);
    this.scene.add(this.particles);
  }

  clearMainGroup() {
    while (this.mainGroup.children.length > 0) {
      const obj = this.mainGroup.children[0];
      this.mainGroup.remove(obj);
      if (obj.geometry) obj.geometry.dispose();
      if (obj.material) {
        if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
        else obj.material.dispose();
      }
    }
    // Re-añadir orbitGroup
    this.orbitGroup = new THREE.Group();
    this.mainGroup.add(this.orbitGroup);
    this.satellites = [];
  }

  // Eventos de ratón, gestos táctiles e interactividad
  setupListeners() {
    const dom = this.renderer.domElement;

    // Movimiento suave siguiendo el ratón (Parallax 3D)
    window.addEventListener('mousemove', (e) => {
      const rect = this.container.getBoundingClientRect();
      const clientX = e.clientX - (rect.left + rect.width / 2);
      const clientY = e.clientY - (rect.top + rect.height / 2);

      this.mouseX = (clientX / window.innerWidth) * 2;
      this.mouseY = (clientY / window.innerHeight) * 2;
    });

    // Arrastre directo con clic o toque para rotación libre 360°
    dom.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;
      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      this.mainGroup.rotation.y += deltaX * 0.008;
      this.mainGroup.rotation.x += deltaY * 0.008;

      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    // Soporte táctil en móviles
    dom.addEventListener('touchstart', (e) => {
      if (e.touches.length === 1) {
        this.isDragging = true;
        this.previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    }, { passive: true });

    window.addEventListener('touchmove', (e) => {
      if (!this.isDragging || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - this.previousMousePosition.x;
      const deltaY = e.touches[0].clientY - this.previousMousePosition.y;

      this.mainGroup.rotation.y += deltaX * 0.01;
      this.mainGroup.rotation.x += deltaY * 0.01;

      this.previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }, { passive: true });

    window.addEventListener('touchend', () => {
      this.isDragging = false;
    });

    // Efecto de pulso / rebote al hacer clic sobre el modelo
    dom.addEventListener('click', () => {
      this.pulseAnimation();
    });

    // Redimensionamiento
    window.addEventListener('resize', () => this.onResize());

    if (window.ResizeObserver) {
      const resizeObserver = new ResizeObserver(() => this.onResize());
      resizeObserver.observe(this.container);
    }
  }

  onResize() {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (width === 0 || height === 0) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  pulseAnimation() {
    const startScale = 1;
    const targetScale = 1.18;
    let t = 0;

    const animatePulse = () => {
      t += 0.08;
      if (t < Math.PI) {
        const factor = 1 + Math.sin(t) * 0.2;
        this.mainGroup.scale.set(factor, factor, factor);
        requestAnimationFrame(animatePulse);
      } else {
        this.mainGroup.scale.set(startScale, startScale, startScale);
      }
    };
    animatePulse();
  }

  // Métodos de control interactivo para la UI
  setMode(mode) {
    if (this.currentMode === mode) return;
    this.currentMode = mode;
    if (mode === 'globe') this.buildGlobeModel();
    else if (mode === 'cube') this.buildCubeModel();
    else if (mode === 'prism') this.buildPrismModel();
  }

  setTheme(themeName) {
    if (!this.colorThemes[themeName]) return;
    this.activeTheme = themeName;
    const theme = this.colorThemes[themeName];
    if (this.dirLight1) this.dirLight1.color.setHex(theme.primary);
    if (this.currentMode === 'globe') this.buildGlobeModel();
    else if (this.currentMode === 'cube') this.buildCubeModel();
    else if (this.currentMode === 'prism') this.buildPrismModel();
  }

  setSpeed(speed) {
    this.rotationSpeed = parseFloat(speed);
  }

  // Bucle de animación continuo
  animate() {
    requestAnimationFrame(() => this.animate());

    const time = performance.now() * 0.001;

    // Rotación suave continua si no se está arrastrando directamente
    if (!this.isDragging) {
      this.mainGroup.rotation.y += this.rotationSpeed;
      // Inclinación reactiva al cursor
      this.targetRotationX = this.mouseY * 0.4;
      this.targetRotationY = this.mouseX * 0.4;
      this.mainGroup.rotation.x += (this.targetRotationX - this.mainGroup.rotation.x) * 0.05;
    }

    // Flotación senoidal elegante (levitación)
    this.mainGroup.position.y = Math.sin(time * 2) * 0.12;

    // Rotación de anillos orbitales
    if (this.orbitRing1) this.orbitRing1.rotation.z += 0.007;
    if (this.orbitRing2) this.orbitRing2.rotation.z -= 0.005;

    // Satélites orbitales
    if (this.satellites) {
      this.satellites.forEach(sat => {
        sat.group.rotation.y += sat.speed;
      });
    }

    // Partículas de fondo girando levemente
    if (this.particles) {
      this.particles.rotation.y = time * 0.02;
      this.particles.rotation.x = Math.sin(time * 0.01) * 0.05;
    }

    this.renderer.render(this.scene, this.camera);
  }
}

// Inicializar cuando el DOM esté listo
window.init3DNewsIcon = (containerId = 'three-canvas-container') => {
  return new Interactive3DNewsIcon(containerId);
};
